<img align="center" src="Image/AzunaTool-Banner.png" width="100%"> 

  - Developed in <strong>Python</strong>, by <a href="https://github.com/AzunaGT1">AzunaGT and supported by </strong>ChatGPT</strong> </a><br>
  - Tool in <strong>English</strong>.<br>
  - Available only on <strong>Windows</strong>.<br>
  - The tool is fully for </strong>Discord</strong>
  <br><br>
</p>

<h1 align="center">Tool</h1>

<p align="center">
  <img src="Image/AzunaTool-Setup.png" width="45%"> 
  <img src="Image/AzunaTool-Menu.png" width="44%"> 
  <br><br>
</p>

<h1 align="center">Features</h1>
<p>
   
```
┌─── Options Menu 1
├─ Token Change Username
├─ Token Change Display Name
├─ Token Change Language
├─ Token Change Status
├─ Token Change Profile Picture
├─ Token Change Bio
├─ Token Change Theme
├─ Token Change House
├─ Token Change Custom Status
├─ Token Change Banner
├─ Token Create Group
├─ Token Join Group
├─ Token Leave Group
├─ Token Create Server [NEW]
├─ Token Rename Server [NEW]
├─ Token Change Server Icon [NEW]
├─ Token Change Server Banner [NEW]
├─ Token Create Channels [NEW]
├─ Token Delete Channels [NEW]
├─ Token Create Roles [NEW]
├─ Token Delete Roles [NEW]
├─ Token Ban Users [NEW]
├─ Token Unban Users [NEW]
├─ Token Kick Users [NEW]
├─ Token Nuke Server [NEW]
├─ Token Join Server
├─ Token Leave Server
├─ Token Disable Friend Request [NEW]
├─ Token Accept Friend Requests [NEW]
├─ Token Reject Friend Requests [NEW]
├──── Options Menu 2
├─ Token Friend Request [NEW]
├─ Token Unfriends
├─ Token Add Friends [NEW]
├─ Token Block Friends
├─ Token Unblock Friends [NEW]
├─ Token Mass DM
├─ Token Delete DM
├─ Token Ghost Ping [NEW]
├─ Token Fake Typing [NEW]
├─ Token Spammer
├─ Token Nuker
├─ Token Crash Chat [NEW]
├─ Token Report [NEW]
├─ Webhook Spammer
├─ Webhook Information
├─ Webhook Delete
├─ Webhook Editor
├─ Bot RAID [NEW]
├─ Token Information
├─ Token Grabber File
└─ Token Boost Server
```
<br><br>
</p>

<h1 align="center">Requirements</h1>

<h3>Windows:</h3>

<p>
- Install <a href="https://www.python.org/downloads/">Python</a> with the </strong>PATH</strong></a> options.<br>
- Windows 10 & 11 or +
</p>

<h1 align="center">Installation</h1>

<p>
  
<a href="https://github.com/AzunaGT1/AzunaTool/releases/tag/DiscordTool">AzunaTool.zip</a>
```
1 - Download the .zip folder.
2 - Unzip the folder.
3 - Launch "Setup.bat".
```

<br><br>
</p>

<h1 align="center">Disclaimer</h1>

<p>
  
  - </strong>AzunaTool</strong> has been developed for </strong>educational purposes only</strong>.<br>
  - This Tool has been created with good intentions and is intended for personal use only.<br>
<br><br>
</p>