try:
    from Program.Configuration.Utilities import *

    import os
    import sys
    import time
    import requests
    import fade
    import subprocess
    import platform
    from concurrent.futures import ThreadPoolExecutor
except:
    MissingModules()

os.system("title AzunaTool │ Startup")
for line in (DiscordLogo).split("\n"):  
    print(line)
    time.sleep(0.01)
time.sleep(1)

if platform.system() == "Windows":
    platform.release()
else:
    ErrorPlateform()

def numtoken(file):
    return sum(1 for _ in open(file, 'r') if _.strip())

def validtoken(token):
    return requests.get("https://discord.com/api/v10/users/@me", headers={"Authorization": token}).status_code == 200

def verif_tokens(file):
    try:
        with open(file, 'r') as f: lines = [_.strip() for _ in f]
        if not lines: raise FileNotFoundError
    except FileNotFoundError:
        os.system("title AzunaTool │ No Token Found")
        print(f"{ERROR} No token found. Add tokens in `Token.txt`.")
        time.sleep(3)
        sys.exit(0)
    return sum(ThreadPoolExecutor(max_workers=100).map(validtoken, lines))

def save(menu_name):
    open(last_menu, "w").write(menu_name)

def load():
    return open(last_menu, "r").read().strip() if os.path.exists(last_menu) else "1"

file = 'Token.txt'
last_menu = "Modules/Configuration/Menu Page.txt"

vtoken_count = verif_tokens(file)
tokenc = numtoken(file)

def Azuna1():
    Clear()    
    os.system("title AzunaTool │ Menu 1")
    gui = f"""                                  ▄████████  ▄███████▄  ███    █▄  ███▄▄▄▄      ▄████████     
                                 ███    ███ ██▀     ▄██ ███    ███ ███▀▀▀██▄   ███    ███ 
                                 ███    ███       ▄███▀ ███    ███ ███   ███   ███    ███ 
                                 ███    ███  ▀█▀▄███▀▄▄ ███    ███ ███   ███   ███    ███ 
                               ▀███████████   ▄███▀   ▀ ███    ███ ███   ███ ▀███████████ 
                                 ███    ███ ▄███▀       ███    ███ ███   ███   ███    ███ 
                                 ███    ███ ███▄     ▄█ ███    ███ ███   ███   ███    ███   
                                 ███    █▀   ▀████████▀ ████████▀   ▀█   █▀    ███    █▀  

                                                    {start}N{end}{white} Next Page {start}1/2{end}
                                            {blue}╔════════════════════════════════╗
                                            {blue}║{white}  Token: {tokenc:<3} | Valid Token:{green} {vtoken_count:>2}  {blue}║
                                            {blue}╚════════════════════════════════╝

            {start}01{end}{white} Token Change Username         {start}11{end}{white} Token Change Banner           {start}21{end}{white} Token Delete Roles
            {start}02{end}{white} Token Change Display Name     {start}12{end}{white} Token Create Group            {start}22{end}{white} Token Ban Users
            {start}03{end}{white} Token Change Language         {start}13{end}{white} Token Leave Group             {start}23{end}{white} Token Unban Users
            {start}04{end}{white} Token Change Status           {start}14{end}{white} Token Rename Group            {start}24{end}{white} Token Kick Users  
            {start}05{end}{white} Token Change Profile Picture  {start}15{end}{white} Token Rename Server           {start}25{end}{white} Token Nuke Server
            {start}06{end}{white} Token Change Bio              {start}16{end}{white} Token Change Server Icon      {start}26{end}{white} Token Join Server
            {start}07{end}{white} Token Change Pronouns         {start}17{end}{white} Token Change Server Banner    {start}27{end}{white} Token Leave Server
            {start}08{end}{white} Token Change Theme            {start}18{end}{white} Token Create Channels         {start}28{end}{white} Token Accept Friend Requests
            {start}09{end}{white} Token Change House            {start}19{end}{white} Token Delete Channels         {start}29{end}{white} Token Reject Friend Requests
            {start}10{end}{white} Token Change Custom Status    {start}20{end}{white} Token Create Roles            {start}30{end}{white} Token Friend Request
"""
    update_message = CheckForUpdate()
    if update_message:
        print(update_message) 

    for line in (fade.water(gui)).split("\n"):  
        print(line)
        time.sleep(0.02)
    
    while True:
        choice = input(f"{blue}┌─{start}{windows_username}@AzunaTool{end}\n└──>{white} ").lstrip("0")              
        if choice in ["n", "next", "N", "Next"]:
            save("Menu 2")
            Azuna2()
        elif choice in ["b", "back", "B", "Back"]:
            print(f"{INFORMATION} Already in Menu 1.")
            time.sleep(1)
            Azuna1()
        elif choice in option:
            subprocess.run(["python", option[choice]])
        else:
            ErrorChoice()

def Azuna2():
    Clear()
    os.system("title AzunaTool │ Menu 2")
    gui = f"""                                  ▄████████  ▄███████▄  ███    █▄  ███▄▄▄▄      ▄████████
                                 ███    ███ ██▀     ▄██ ███    ███ ███▀▀▀██▄   ███    ███
                                 ███    ███       ▄███▀ ███    ███ ███   ███   ███    ███
                                 ███    ███  ▀█▀▄███▀▄▄ ███    ███ ███   ███   ███    ███
                               ▀███████████   ▄███▀   ▀ ███    ███ ███   ███ ▀███████████
                                 ███    ███ ▄███▀       ███    ███ ███   ███   ███    ███
                                 ███    ███ ███▄     ▄█ ███    ███ ███   ███   ███    ███   
                                 ███    █▀   ▀████████▀ ████████▀   ▀█   █▀    ███    █▀

                                                    {start}B{end}{white} Back Page {start}2/2{end}
                                            {blue}╔════════════════════════════════╗
                                            {blue}║{white}  Token: {tokenc:<3} | Valid Token:{green} {vtoken_count:>2}  {blue}║    
                                            {blue}╚════════════════════════════════╝

            {start}31{end}{white} Token Unfriends               {start}41{end}{white} Webhook Spammer               {start}51{end}{white}
            {start}32{end}{white} Token Add Friends             {start}42{end}{white} Webhook Information           {start}52{end}{white}
            {start}33{end}{white} Token Block Friends           {start}43{end}{white} Webhook Delete                {start}53{end}{white}
            {start}34{end}{white} Token Unblock Friends         {start}44{end}{white} Webhook Editor                {start}54{end}{white}
            {start}35{end}{white} Token Mass DM                 {start}45{end}{white} Bot RAID                      {start}55{end}{white}
            {start}36{end}{white} Token Delete DM               {start}46{end}{white} Token Information             {start}56{end}{white}
            {start}37{end}{white} Token Spammer                 {start}47{end}{white} Token Grabber/Injection File  {start}57{end}{white}
            {start}38{end}{white} Token Nuker                   {start}48{end}{white} Token Boost Server            {start}58{end}{white}
            {start}39{end}{white} Token Cleaner                 {start}49{end}{white} Token Login                   {start}59{end}{white}
            {start}40{end}{white} Token Mass Report             {start}50{end}{white}                               {start}60{end}{white}
""" 
    update_message = CheckForUpdate()
    if update_message:
        print(update_message) 

    for line in (fade.water(gui)).split("\n"):  
        print(line)
        time.sleep(0.02)        

    while True:
        choice = input(f"{blue}┌─{start}{windows_username}@AzunaTool{end}\n└──>{white} ").lstrip("0")
              
        if choice in ["b", "back", "B", "Back"]:
            save("Menu 1")
            Azuna1()
        elif choice in ["n", "next", "N", "Next"]:
            print(f"{INFORMATION} Already in Menu 2{reset}")
            time.sleep(1)
            Azuna2()
        elif choice in option:
            subprocess.run(["python", option[choice]])
        else:
            ErrorChoice()

option = {
    "1": "Program/Token-Change-Username.py",
    "2": "Program/Token-Change-Display-Name.py",
    "3": "Program/Token-Change-Language.py",
    "4": "Program/Token-Change-Status.py",
    "5": "Program/Token-Change-Profile-Picture.py",
    "6": "Program/Token-Change-Bio.py",
    "7": "Program/Token-Change-Pronouns.py",
    "8": "Programs/Token-Change-Theme.py",
    "9": "Program/Token-Change-House.py",
    "10": "Program/Token-Change-Custom-Status.py",
    "11": "Program/Token-Change-Banner.py",
    "12": "Program/Token-Create-Group.py",
    "13": "Program/Token-Leave-Group.py",
    "14": "Program/Token-Rename-Group.py",
    "15": "Program/Token-Rename-Server.py",
    "16": "Program/Token-Change-Server-Icon.py",
    "17": "Program/Token-Change-Server-Banner.py",
    "18": "Program/Token-Create-Channels.py",
    "19": "Program/Token-Delete-Channels.py",
    "20": "Program/Token-Create-Roles.py",
    "21": "Program/Token-Delete-Roles.py",
    "22": "Program/Token-Ban-Users.py",
    "23": "Program/Token-Unban-Users.py",
    "24": "Program/Token-Kick-Users.py",
    "25": "Program/Token-Nuke-Server.py",
    "26": "Program/Token-Join-Server.py",
    "27": "Program/Token-Leave-Server.py",
    "28": "Program/Token-Accept-Friend-Requests.py",
    "29": "Program/Token-Reject-Friend-Requests.py",
    "30": "Program/Token-Friend-Request.py",
    "31": "Program/Token-Unfriends.py",
    "32": "Program/Token-Add-Friends.py",
    "33": "Program/Token-Block-Friends.py",
    "34": "Program/Token-Unblock-Friends.py",
    "35": "Program/Token-Mass-DM.py",
    "36": "Program/Token-Delete-DM.py",
    "37": "Program/Token-Spammer.py",
    "38": "Program/Token-Nuker.py",
    "39": "Programs/Token-Cleaner.py",
    "40": "Program/Token-Mass-Report.py",
    "41": "Program/Webhook-Spammer.py",
    "42": "Program/Webhook-Information.py",
    "43": "Program/Webhook-Delete.py",
    "44": "Program/Webhook-Editor.py",
    "45": "Program/Bot-RAID.py",
    "46": "Program/Token-Information.py",
    "47": "Program/Token-Grabber-File.py",
    "48": "Program/Token-Boost-Server.py",
    "49": "Program/Token-Login.py"
}

if load() == "Menu 2":
    Azuna2()
else:
    Azuna1()