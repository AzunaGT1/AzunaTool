try:
    from Configuration.Utilities import *

    import requests
    import json
except:
    MissingModules()

def get_custom_status(token):
    url = "https://discord.com/api/v10/users/@me/settings"
    headers = {
        "Authorization": token
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            custom_status = data.get("custom_status")
            if custom_status and isinstance(custom_status, dict):
                return custom_status.get("text", "Not set")
            else:
                return "Not set"  
        else:
            return "Not set" 
    except requests.RequestException:
        return "Error"

def set_custom_status(token, status_text):
    url = "https://discord.com/api/v10/users/@me/settings"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }

    data = {
        "custom_status": {
            "text": status_text
        }
    }

    try:
        response = requests.patch(url, headers=headers, data=json.dumps(data))
        return response
    except requests.RequestException as e:
        return e

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            nitro = NitroType(token)
            valid_tokens.append((token, username, global_name))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            ErrorChoice()
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name = [info for info in valid_tokens if info[0] == chosen_token][0]

                current_status = get_custom_status(token)
                print(f"\n{INFORMATION} Current Custom Status: {white}{current_status}")

                new_status = input(f"{INPUT} New Custom Status    :{white} ").strip()

                response = set_custom_status(token, new_status)

                if isinstance(response, requests.Response) and response.status_code == 200:
                    print(f"{SUCCESS} Custom status successfully changed.")
                    Return()
                else:
                    print(f"{ERROR} Error        : {white}{response.status_code}")
                    print(f"{ERROR} Error Message: {white}{response.json()}")
                    Return()
            else:
                ErrorChoice()
    else:
        NoTokenFound()