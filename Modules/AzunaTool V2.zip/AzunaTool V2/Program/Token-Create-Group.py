try:
    from Configuration.Utilities import *

    import requests
    import json
except:
    MissingModules()

def create_group(token, friends_ids):
    url = "https://discord.com/api/v10/users/@me/channels"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }

    data = {
        "recipients": friends_ids,
        "type": 1,
    }

    try:
        response = requests.post(url, headers=headers, data=json.dumps(data))
        return response
    except requests.RequestException as e:
        print(f"{ERROR} Error while creating group: {str(e)}")
        return None

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            valid_tokens.append((token, username, global_name))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            ErrorChoice()
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name = [info for info in valid_tokens if info[0] == chosen_token][0]

                friends = FriendsList(chosen_token)

                if friends:
                    friends_list = [(friend['user']['id'], friend['user']['username']) for friend in friends]
                    
                    for i, (friend_id, friend_name) in enumerate(friends_list, 1):
                        max_name_length = max(len(friend_name) for _, friend_name in friends_list)
                        print(f"{CHOICE} {start}{i:03}{end} Friend Name:{white} {friend_name.ljust(max_name_length)} |{blue} Friend ID:{white} {friend_id}")

                    print(f"\n{INFORMATION} Separate friends with commas + space.")
                    choice_input = input(f"{INPUT} Choose Friends :{white} ").strip("0")

                    selected_ids = []
                    choices = choice_input.split(", ")
                    for choice in choices:
                        try:
                            choice = int(choice.strip())
                            if 1 <= choice <= len(friends_list):
                                selected_ids.append(friends_list[choice - 1][0])
                            else:
                                ErrorChoice()
                        except ValueError:
                            ErrorChoice()

                    if len(selected_ids) > 9:
                        print(f"{ERROR} You cannot create a group with more than 10 members.")
                        Return()
                    else:
                        selected_ids.append(UserInfo(chosen_token)['id'])

                        number_of_groups = input(f"{INPUT} Number Of Group: {white}").strip()
                        if not number_of_groups.isdigit() or int(number_of_groups) < 1 or int(number_of_groups) > 10:
                            ErrorNumber()
                        else:
                            number_of_groups = int(number_of_groups)
                        
                        for i in range(number_of_groups):
                            print(f"{LOADING}  {i + 1} / {number_of_groups}.")

                            response = create_group(chosen_token, selected_ids)

                            if not isinstance(response, requests.Response) or response.status_code != 200:
                                if response is not None:
                                    print(f"{ERROR} Error        :{white} {response.status_code}")
                                    print(f"{ERROR} Error Message:{white} {response.text}")
                        
                        if number_of_groups > 1:
                            print(f"{SUCCESS} All groups successfully created.")
                        else:
                            print(f"{SUCCESS} Group successfully created.")
                        Return()
                else:
                    NoFriendsFound()
            else:
                ErrorChoice()
else:
    NoTokenFound()