try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def get_user_guilds(token):
    url = "https://discord.com/api/v10/users/@me/guilds"
    headers = {"Authorization": token}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    return None

def change_guild_banner(token, guild_id, new_banner_base64):
    url = f"https://discord.com/api/v10/guilds/{guild_id}"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "banner": new_banner_base64
    }
    return requests.patch(url, headers=headers, json=data)

def account_choices(valid_tokens):
    tokens_dict = {}
    max_username_length = max(len(info[1]) for info in valid_tokens)
    max_global_name_length = max(len(info[2]) for info in valid_tokens)
    
    for i, (token, username, global_name) in enumerate(valid_tokens, 1):
        print(f"{CHOICE} {start}{i:02}{end} Username: {white}{username.ljust(max_username_length)} |{blue} Display Name: {white}{global_name.ljust(max_global_name_length)} |{blue} Nitro Type:{white} {NitroType(token)}")
        tokens_dict[i] = token
    return tokens_dict

def get_server_banner_url(guild_id):
    url = f"https://discord.com/api/v10/guilds/{guild_id}"
    headers = {"Authorization": token}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json().get('banner', None)
    return None

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        try:
            user_info = UserInfo(token)
            if "username" in user_info:
                username = user_info["username"]
                global_name = user_info.get("global_name", "Unknown")
                valid_tokens.append((token, username, global_name))
        except:
            continue

    if valid_tokens:
        tokens_dict = account_choices(valid_tokens)
        
        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()
        
        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name = [info for info in valid_tokens if info[0] == chosen_token][0]

                print(f"\n{CHOICE} {start}01{end}{white} Specific Server")
                print(f"{CHOICE} {start}02{end}{white} All Servers")
                action_input = input(f"\n{INPUT} Choice ->{white} ").strip("0")

                if action_input in "1":
                    guilds = get_user_guilds(token)
                    if guilds:
                        guilds_dict = {}
                        guilds_list = [(guild['id'], guild.get('name', 'Unnamed Server')) for guild in guilds if guild.get('owner_id') == user_info['id'] and guild.get('premium_subscription_count', 0) > 0]
                        if not guilds_list:
                            print(f"{ERROR} No servers have sufficient boosts.")
                        time.sleep(1)
                        Clear()
                        Main()
                        max_name_length = max(len(name) for _, name in guilds_list)

                        for i, (guild_id, name) in enumerate(guilds_list, 1):
                            print(f"{CHOICE} {start}{i:03}{end}{white} {name}")
                            guilds_dict[i] = guild_id

                        selected_input = input(f"\n{INPUT} Choice ->{white} ").strip("0")

                        try:
                            selected_num = int(selected_input)
                            selected_guild_id = guilds_dict.get(selected_num)

                            if selected_guild_id:
                                banner_url = get_server_banner_url(selected_guild_id)
                                print(f"{INFORMATION} Current Banner URL: {white}{banner_url or 'No banner set'}")

                                image_path = input(f"{INPUT} New Banner Path   :{white} ").strip()
                                new_banner_base64 = EncodeImageBase64(image_path)

                                response = change_guild_banner(token, selected_guild_id, new_banner_base64)

                                if response.status_code == 200:
                                    print(f"{SUCCESS} Server banner successfully changed!")
                                else:
                                    print(f"{ERROR} Error        : {white}{response.status_code}")
                                    print(f"{ERROR} Error Message: {white}{response.text}")
                                Return()
                            else:
                                ErrorNumber()
                        except ValueError:
                            print(ErrorChoice())
                    else:
                        print(ErrorNumber())

                elif action_input in "2":
                    guilds = get_user_guilds(token)
                    if guilds:
                        guilds = [guild for guild in guilds if guild.get('owner_id') == user_info['id'] and guild.get('premium_subscription_count', 0) > 0]

                        if not guilds:
                            print(f"{ERROR} No servers have sufficient boosts.")
                        time.sleep(1)
                        Clear()
                        Main()

                        new_banner_image = input(f"{INPUT} New Banner Path:{white} ").strip()

                        new_banner_base64 = EncodeImageBase64(new_banner_image)

                        for guild in guilds:
                            guild_id = guild['id']
                            response = change_guild_banner(token, guild_id, new_banner_base64)

                            if response.status_code == 200:
                                print(f"{SUCCESS} Server banner successfully changed.")
                            else:
                                print(f"{FAILED} Failed to change banner.")
                            Return()
                    else:
                        print(f"{ERROR} No servers found.")
                else:
                    print(f"{ERROR} No servers found.")
                    Return()
            else:
                ErrorChoice()
else:
    NoTokenFound()