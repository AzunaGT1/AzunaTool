try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def change_status(token, status):
    url = "https://discord.com/api/v9/users/@me/settings"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "status": status
    }

    try:
        response = requests.patch(url, headers=headers, json=data)
        return response
    except requests.RequestException as e:
        return e

status_map = {
    "01": ("Online", "online"),
    "1": ("Online", "online"),
    "02": ("Idle", "idle"),
    "2": ("Idle", "idle"),
    "03": ("Do Not Disturb", "dnd"),
    "3": ("Do Not Disturb", "dnd"),
    "04": ("Invisible", "invisible"),
    "4": ("Invisible", "invisible")
}

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            valid_tokens.append((token, username, global_name))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                print(f"\n{CHOICE} {start}01{end}{white} Online")
                print(f"{CHOICE} {start}02{end}{white} Idle")
                print(f"{CHOICE} {start}03{end}{white} Do Not Disturb")
                print(f"{CHOICE} {start}04{end}{white} Invisible")

                user_info = UserInfo(chosen_token)
                print(f"\n{INFORMATION} Current Status: {white}{user_info.get('status', 'Unknown')}")

                status_choice = input(f"{INPUT} New Status    :{white} ").strip()

                if status_choice in status_map:
                    display_name, status_code = status_map[status_choice]

                    response = change_status(chosen_token, status_code)

                    if isinstance(response, requests.Response) and response.status_code == 200:
                        print(f"{SUCCESS} Status successfully changed.")
                    else:
                        print(f"{ERROR} Error        : {white}{response.status_code}")
                        print(f"{ERROR} Error Message: {white}{response.text}")
                    Return()
                else:
                    ErrorChoice()
            else:
                ErrorChoice()
    else:
        NoTokenFound()