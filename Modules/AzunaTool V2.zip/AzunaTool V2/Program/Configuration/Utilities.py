try:
    import getpass, os, time, subprocess, requests, webbrowser, base64
except:
    os.system("title AzunaTool │ Missing Modules")
    input("Not all modules are installed, please run 'Setup.bat'.")
    exit()

#------------------[ Configuration ]------------------

nametool     =  "AzunaTool"
versiontool  =  "V1"
codingtool   =  "Python"
languagetool =  "EN"
creator      =  "AzunaGT1"
platform_pc  =  "Windows 10/11"
urltool      =  "https:/github.com/AzunaGT1/AzunaTool"

#------------------[   Utilities   ]------------------

path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

def Main():
    subprocess.run(['python', os.path.join(path, "AzunaTool.py")])

def Clear():
    os.system("cls")

def NoFriendsFound():
    print(f"{ERROR} No friends found, please try again.")
    time.sleep(1)
    Clear()
    Main()     

def ErrorChoice():
    print(f"{ERROR} Invalid choice, please try again.")
    time.sleep(1)
    Clear()
    Main() 

def ErrorUrl():
    print(f"{ERROR} Invalid url, please try again.")
    time.sleep(1)
    Clear()
    Main() 

def ErrorAction():
    print(f"{ERROR} Invalid action, please try again.")
    time.sleep(1)
    Clear()
    Main()

def NoTokenFound():
    print(f"{ERROR} No token found. Add tokens in `Token.txt`.")
    time.sleep(1)
    Clear()
    Main()     

def NoInfoToken():
    print(f"{ERROR} Unable to retrieve token information.")
    time.sleep(1)
    Clear()
    Main()    

def ErrorBotToken():
    print(f"{ERROR} Invalid bot token, please try again.")
    time.sleep(1)
    Clear()
    Main() 

def ErrorToken():
    print(f"{ERROR} Invalid token, please add valid tokens in `Token.txt`.")
    time.sleep(1)
    Clear()
    Main()        

def ErrorID():
    print(f"{ERROR} Invalid ID, please try again.")
    time.sleep(1)
    Clear()
    Main()   

def ErrorWebhook():
    print(f"{ERROR} Invalid webhook, please try again.")
    time.sleep(1)
    Clear()
    Main()      

def ErrorPlateform():
    print(f"{ERROR} Invalid platform, this tool is only designed for Windows.")
    time.sleep(1)
    Clear()
    Main() 

def MissingModules():
    input("Not all modules are installed, please run 'Setup.bat'")
    Clear()

def ErrorNumber():
    print(f"{ERROR} Invalid number, please try again.")
    time.sleep(1)
    Clear()
    Main()   

def Return():
    input(f"\n{INFORMATION} Press {start}Enter{end}{blue} to return to the main menu.")
    Clear()
    Main()

def EncodeImageBase64(file_path):
    with open(file_path, "rb") as image_file:
        encoded = base64.b64encode(image_file.read()).decode('utf-8')
        return f"data:image/png;base64,{encoded}"

def FriendsList(token):
    url = "https://discord.com/api/v10/users/@me/relationships"
    headers = {
        "Authorization": token
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            return None
    except requests.RequestException:
        return None

def UserInfo(token):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json()
        else:
            return None
    except requests.RequestException:
        return None

def NitroType(token):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token
    }
    response = requests.get(url, headers=headers)

    if response.status_code == 200: 
        user_data = response.json()
        if "premium_type" in user_data:
            premium_type = user_data["premium_type"]
            if premium_type == 0:
                return "No Nitro"
            elif premium_type == 1:
                return "Nitro Basic"
            elif premium_type == 2:
                return "Nitro Boost"
        else:
            return "No Nitro"

def CheckWebhook(webhook):
    try:
        response = requests.get(webhook)
        if response.status_code == 200 or response.status_code == "200":
            with open('Configuration/1-WebhookURL.txt', "w") as file:
                file.write(webhook)
            return True
        else:
            ErrorWebhook()
    except:
        print(f"{ERROR} Webhook connection error, please try again.")
        time.sleep(1)
        Clear()
        Main()

def CheckForUpdate():
    try:
        latest = requests.get("https://api.github.com/repos/AzunaGT1/AzunaTool/releases/latest", timeout=5).json().get("tag_name")
        if latest and latest != f"{versiontool}":
            print(f"{yellow}New Version{reset} | {green}{versiontool}{white} ──> {green}{latest}")
            webbrowser.open(f"{urltool}/releases/latest")
        else:
            print(f"{start_green}{white}V{end_green} Latest Version{white} | {start_green}{versiontool}{end_green}")
    except requests.RequestException:
        pass

windows_username = getpass.getuser()

webhook_color    = 3447003
webhook_username = "AzunaTool"
webhook_avatar   = "https://cdn.discordapp.com/avatars/1359098134604550197/720059ad687ef0c4601ce334ccf3f414.png"

reset            = "\033[0m"
white            = "\033[37m"
blue             = "\033[34m"
green            = "\033[32m"
yellow           = "\033[33m"
red              = "\033[31m"

start            = f"{blue}[{white}"
end              = f"{blue}]"
start_red        = f"{red}[{white}"
end_red          = f"{red}]"
start_green      = f"{green}[{white}"
end_green        = f"{green}]"
start_yellow     = f"{yellow}[{white}"
end_yellow       = f"{yellow}]"

#----------------------[ Inspired by RedTiger ]----------------------

INPUT            = f"{start + ">" + end} {white}|{blue}"
CHOICE           = f"{start + ">" + end} {white}|{blue}"
INFORMATION      = f"{start + "i" + end} {white}|{blue}"
LOADING          = f"{start_yellow + "~" + end_yellow} {white}|{yellow}"
ERROR            = f"{start_red + "!" + end_red} {white}|{red}"
SUCCESS          = f"{start_green + "+" + end_green} {white}|{green}"
FAILED           = f"{start_red + "-" + end_red} {white}|{red}"

#--------------------------------------------------------------------

DiscordLogo = (f"""{blue}
                                                  @@@@                @%@@                                      
                                           @@@@@@@@@@@@               @@@@@@@@@@%                               
                                      @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                          
                                     @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%                         
                                    %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                        
                                   @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                       
                                  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                      
                                 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                     
                                @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%                    
                               @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                   
                              %@@@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@    @@@@@@@@@@@@@@@@@@%                  
                              %@@@@@@@@@@@@@@@@        %@@@@@@@@@@@%@        @@@@@@@@@@@@@@@@@                  
                              %@@@@@@@@@@@@@@@          @@@@@@@@@@@@          @@@@@@@@@@@@@@@%                  
                             %@@@@@@@@@@@@@@@@     {white}0{blue}    @@@@@@@@@@@%    {white}0{blue}     %@@@@@@@@@@@@@@@@                 
                             @@@@@@@@@@@@@@@@@%         @@@@@@@@@@@%        %@@@@@@@@@@@@@@@@@                 
                             @@@@@@@@@@@@@@@@@@@      %@@@@@@@@@@@@@@@      @@@@@@@@@@@@@@@@@@%                 
                             %@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%                 
                             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%                 
                             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                 
                             @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%                 
                               @%@@@@@@@@@@@@@%@@   @@@@%@@@@@@@@@%%%@%@@  @@@@@@@@@@@@@@@@@@                   
                                  @@%@@@@@@@@@@@@@                        @%@@@@@@@@@@@%@@                      
                                       @%@@@@@@@           {white}Azuna{blue}            @@@@@@%%@                           
                                             @@      {white}Best Discord Tool{blue}       @@                           
""")