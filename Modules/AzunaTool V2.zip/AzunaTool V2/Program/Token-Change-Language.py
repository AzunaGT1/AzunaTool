try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()
    
LANGUAGES = {
    "01": ("English (US)", "en-US"),              
    "02": ("English (UK)", "en-GB"),               
    "03": ("French", "fr"),
    "04": ("Spanish (Spain)", "es-ES"),           
    "05": ("Spanish (Latin America)", "es-419"), 
    "06": ("Portuguese (Portugal)", "pt-PT"),
    "07": ("Portuguese (Brazil)", "pt-BR"),
    "08": ("German", "de"),
    "09": ("Italian", "it"),
    "10": ("Dutch", "nl"),
    "11": ("Polish", "pl"),
    "12": ("Romanian", "ro"),
    "13": ("Russian", "ru"),
    "14": ("Turkish", "tr"),
    "15": ("Ukrainian", "uk"),
    "16": ("Czech", "cs"),
    "17": ("Hungarian", "hu"),
    "18": ("Chinese (Simplified)", "zh-CN"),
    "19": ("Chinese (Traditional)", "zh-TW"),
    "20": ("Japanese", "ja"),
    "21": ("Korean", "ko"),
    "22": ("Vietnamese", "vi"),
    "23": ("Swedish", "sv-SE"),
    "24": ("Thai", "th"),
    "25": ("Indonesian", "id"),
    "26": ("Hindi", "hi"),
    "27": ("Malay", "ms"),
}

def change_language(token, locale_code):
    url = "https://discord.com/api/v10/users/@me/settings"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "locale": locale_code
    }

    try:
        response = requests.patch(url, headers=headers, json=data)
        return response
    except requests.RequestException as e:
        return e

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        info = UserInfo(token)
        if info:
            username = info.get("username", "Unknown")
            global_name = info.get("global_name", "Unknown")
            locale = info.get("locale", "Unknown")
            valid_tokens.append((token, username, global_name, locale))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name, _ in valid_tokens)


        for i, (token, username, global_name, locale) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

        if chosen_token:
            user_info = UserInfo(chosen_token)
            username = user_info.get('username', 'Unknown')
            global_name = user_info.get('global_name', 'Unknown')
            current_locale = user_info.get('locale', 'Unknown')

            for code, (label, _) in LANGUAGES.items():
                print(f"{CHOICE} {start}{code}{end} {white}{label}")

            print(f"\n{INFORMATION} Current Language: {white}{current_locale}")
            lang_choice = input(f"{INPUT} New Language    :{white} ").strip()
            lang_key = f"{int(lang_choice):02}"

            if lang_key in LANGUAGES:
                lang_name, lang_code = LANGUAGES[lang_key]
                response = change_language(chosen_token, lang_code)

                if isinstance(response, requests.Response) and response.status_code == 200:
                    print(f"{SUCCESS} Language successfully changed.")
                else:
                    print(f"{ERROR} Error        : {white}{response.status_code}")
                    print(f"{ERROR} Error Message: {white}{response.json()}")
                Return()
            else:
                ErrorChoice()
        else:
            ErrorChoice()
else:
    NoTokenFound()
