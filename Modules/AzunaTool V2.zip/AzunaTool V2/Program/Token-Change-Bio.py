try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def change_bio(token, new_bio):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "bio": new_bio
    }

    try:
        response = requests.patch(url, headers=headers, json=data)
        return response
    except requests.RequestException as e:
        return e

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            bio = user_info.get("bio", "No bio set")
            nitro = NitroType(token)
            valid_tokens.append((token, username, global_name, bio))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name, _ in valid_tokens)

        for i, (token, username, global_name, bio) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name, current_bio = [info for info in valid_tokens if info[0] == chosen_token][0]

                print(f"\n{INFORMATION} Current Bio: {white}{current_bio}")

                new_bio = input(f"{INPUT} New Bio    : {white} ").strip()

                try:
                    response = change_bio(chosen_token, new_bio)

                    if isinstance(response, requests.Response) and response.status_code == 200:
                        print(f"{SUCCESS} Bio successfully changed.")
                        Return()
                    else:
                        print(f"{ERROR} Error        : {white}{response.status_code}")
                        print(f"{ERROR} Error Message: {white}{response.text}")
                        Return()
                except Exception as e:
                    print(f"{ERROR} Error while changing the bio: {white}{str(e)}")
            else:
                ErrorChoice()
else:
    NoTokenFound()