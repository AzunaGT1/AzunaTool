try:
    from Configuration.Utilities import *

    import requests
    import json
except:
    MissingModules()

def get_banner_url(token):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            user_data = response.json()
            banner = user_data.get("banner", "Unknow")
            if banner:
                return f"https://cdn.discordapp.com/banners/{user_data['id']}/{banner}.png"
            else:
                return None
        else:
            return None
    except requests.RequestException:
        return None

def set_banner_url(token, image_url):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "banner": new_banner_base64
    }

    try:
        response = requests.patch(url, headers=headers, data=json.dumps(data))
        return response
    except requests.RequestException as e:
        return e

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            valid_tokens.append((token, username, global_name))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            ErrorChoice()
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name = [info for info in valid_tokens if info[0] == chosen_token][0]

                current_banner = get_banner_url(token)
                print(f"\n{INFORMATION} Current Banner URL: {white}{current_banner}")

                new_banner_url = input(f"{INPUT} New Banner Path   :{white} ").strip()
                new_banner_base64 = EncodeImageBase64(new_banner_url)

                if new_banner_url:
                    response = set_banner_url(token, new_banner_url)

                    if isinstance(response, requests.Response) and response.status_code == 200:
                        print(f"{SUCCESS} Banner successfully changed.")
                        Return()
                    else:
                        print(f"{ERROR} Error        : {white}{response.status_code}")
                        print(f"{ERROR} Error Message: {white}{response.text}")
                        Return()
                else:
                    ErrorUrl()
            else:
                ErrorChoice()
else:
    NoTokenFound()