try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def get_hypesquad_house(token):
    url = "https://discord.com/api/v10/users/@me/hypesquad/online"
    headers = {
        "Authorization": token
    }

    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json().get("house_id", None)
        else:
            return None
    except requests.RequestException:
        return None

def set_hypesquad_house(token, house_id):
    url = "https://discord.com/api/v10/hypesquad/online"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "house_id": house_id
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        return response
    except requests.RequestException as e:
        return e

house_names = {
    1: "Bravery",
    2: "Brilliance",
    3: "Balance"
}

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        current_house_id = get_hypesquad_house(token)
        current_house = house_names.get(current_house_id, "None")

        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            valid_tokens.append((token, username, global_name, current_house))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name, _ in valid_tokens)

        for i, (token, username, global_name, current_house) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name, current_house = [info for info in valid_tokens if info[0] == chosen_token][0]

                print(f"\n{CHOICE} {start}01{end}{white} HypeSquad Bravery")
                print(f"{CHOICE} {start}02{end}{white} HypeSquad Brilliance")
                print(f"{CHOICE} {start}03{end}{white} HypeSquad Balance")

                print(f"\n{INFORMATION} Current House : {white}{current_house}")
                new_house_input = input(f"{INPUT} New House     : {white}").lstrip("0")

                if new_house_input in ["1", "2", "3"]:
                    new_house_id = int(new_house_input)
                    response = set_hypesquad_house(token, new_house_id)

                    if isinstance(response, requests.Response) and response.status_code == 204:
                        print(f"{SUCCESS} HypeSquad house successfully changed.")
                        Return()
                    else:
                        print(f"{ERROR} Error        : {white}{response.status_code}")
                        print(f"{ERROR} Error Message: {white}{response.text}")
                        Return()
                else:
                    ErrorChoice()
            else:
                ErrorChoice()
else:
    NoTokenFound()