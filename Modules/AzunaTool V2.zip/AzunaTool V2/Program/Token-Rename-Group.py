try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def get_group_dms(token):
    url = "https://discord.com/api/v10/users/@me/channels"
    headers = {"Authorization": token}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return [c for c in response.json() if c.get("type") == 3]
    return None

def change_group_name(token, channel_id, new_name):
    url = f"https://discord.com/api/v10/channels/{channel_id}"
    headers = {"Authorization": token, "Content-Type": "application/json"}
    data = {
        "name": new_name
    }
    return requests.patch(url, headers=headers, json=data)

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        try:
            user_info = UserInfo(token)
            if "username" in user_info:
                username = user_info["username"]
                global_name = user_info.get("global_name", "Unknown")
                valid_tokens.append((token, username, global_name))
        except:
            continue

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name = [info for info in valid_tokens if info[0] == chosen_token][0]

                print(f"\n{CHOICE} {start}01{end}{white} Specific Group")
                print(f"{CHOICE} {start}02{end}{white} All Groups")
                action_input = input(f"\n{INPUT} Choice ->{white} ").strip("0")

                if action_input in "1":
                    group_dms = get_group_dms(token)
                    if group_dms:
                        groups_dict = {}
                        groups_list = [(group['id'], group.get('name') or 'Unnamed Group') for group in group_dms]

                        for i, (group_id, name) in enumerate(groups_list, 1):
                            invite_url = f"https://discord.com/channels/@me/{group_id}"
                            print(f"{CHOICE} {start}{i:03}{end}{white} {name}")
                            groups_dict[i] = group_id

                        selected_input = input(f"\n{INPUT} Choice ->{white} ").strip("0")

                        try:
                            selected_num = int(selected_input)
                            selected_group_id = groups_dict.get(selected_num)

                            if selected_group_id:
                                group_name = [group['name'] for group in group_dms if group['id'] == selected_group_id][0]
                                print(f"\n{INFORMATION} Current Name: {white}{group_name}")

                                new_group_name = input(f"{INPUT} New Name    :{white} ").strip()

                                response = change_group_name(token, selected_group_id, new_group_name)
                                if response.status_code == 200:
                                    print(f"{SUCCESS} Group name successfully changed!")
                                else:
                                    print(f"{ERROR} Error        : {white}{response.status_code}")
                                    print(f"{ERROR} Error Message: {white}{response.text}")
                                Return()
                            else:
                                print(f"{ERROR} Invalid group number.")
                        except ValueError:
                            ErrorChoice()
                    else:
                        ErrorNumber()

                elif action_input in "2":
                    group_dms = get_group_dms(token)
                    if group_dms:
                        new_group_name = input(f"{INPUT} New name:{white} ").strip()

                        max_name_length = max(len(group.get('name', 'Unnamed Group')) for group in group_dms)

                        for group in group_dms:
                            group_id = group['id']
                            old_group_name = group.get('name', 'Unnamed Group')
                            response = change_group_name(token, group_id, new_group_name)

                            if response.status_code == 200:
                                print(f"{SUCCESS} Group successfully renamed.{white} |{green} '{old_group_name.ljust(max_name_length)}' -> {new_group_name}")
                            else:
                                print(f"{FAILED} Failed to rename group.{white}     |{green} '{old_group_name.ljust(max_name_length)}' -> {new_group_name}")
                        Return()
                    else:
                        print(f"{ERROR} No groups found.")
                else:
                    ErrorChoice()
            else:
                ErrorChoice()
else:
    NoTokenFound()