try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def change_profile_picture(token, image_url):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "avatar": new_image_base64
    }

    try:
        response = requests.patch(url, headers=headers, json=data)
        return response
    except requests.RequestException as e:
        return e

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        user_info = UserInfo(token)
        if user_info:
            username = user_info.get("username", "Unknown")
            global_name = user_info.get("global_name", "Unknown")
            current_avatar = user_info.get("avatar", "None")
            avatar_url = f"https://cdn.discordapp.com/avatars/{user_info['id']}/{current_avatar}.png" if current_avatar else None
            valid_tokens.append((token, username, global_name, avatar_url, None))  

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _, _, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name, _, _ in valid_tokens)

        for i, (token, username, global_name, avatar_url, _) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                selected_info = [info for info in valid_tokens if info[0] == chosen_token]
        
                if selected_info: 
                    token, username, global_name, avatar_url, _ = selected_info[0]  
                    print(f"\n{INFORMATION} Current Profile Picture URL: {white}{avatar_url}")

                    image_url = input(f"{INPUT} New Profile Picture Path   :{white} ").strip()
                    new_image_base64 = EncodeImageBase64(image_url)

                    try:
                        response = change_profile_picture(chosen_token, image_url)

                        if isinstance(response, requests.Response) and response.status_code == 200:
                            print(f"{SUCCESS} Profile picture successfully changed.")
                        else:
                            print(f"{ERROR} Error        : {white}{response.status_code}")
                            print(f"{ERROR} Error Message: {white}{response.text}")
                        Return()
                    except Exception as e:
                        print(f"{ERROR} Error while changing the profile picture: {white}{str(e)}")
            else:
                ErrorChoice()
else:
    NoTokenFound()