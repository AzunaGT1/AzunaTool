try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def get_user_guilds(token):
    url = "https://discord.com/api/v10/users/@me/guilds"
    headers = {"Authorization": token}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        guilds = response.json()
        owner_guilds = [guild for guild in guilds if guild['owner']]
        return owner_guilds
    else:
        print(f"{ERROR} Error:{white} {response.status_code}")
        return []

def change_guild_icon(token, guild_id, new_icon_url):
    url = f"https://discord.com/api/v10/guilds/{guild_id}"
    headers = {"Authorization": token, "Content-Type": "application/json"}
    data = {
        "icon": new_icon_base64
    }
    return requests.patch(url, headers=headers, json=data)

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        try:
            user_info = UserInfo(token)
            if "username" in user_info:
                username = user_info["username"]
                global_name = user_info.get("global_name", "Unknown")
                valid_tokens.append((token, username, global_name))
        except:
            continue

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

        choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

        if not choice_input.isdigit():
            print(ErrorChoice())
        else:
            choice = int(choice_input)
            chosen_token = tokens_dict.get(choice)

            if chosen_token:
                token, username, global_name = [info for info in valid_tokens if info[0] == chosen_token][0]

                print(f"\n{CHOICE} {start}01{end}{white} Specific Server")
                print(f"{CHOICE} {start}02{end}{white} All Servers")
                action_input = input(f"\n{INPUT} Choice ->{white} ").strip("0")

                if action_input in "1":
                    guilds = get_user_guilds(token)
                    if guilds:
                        guilds_dict = {}
                        guilds_list = [(guild['id'], guild.get('name') or 'Unnamed Server', guild.get('icon')) for guild in guilds]
                        if not guilds_list:
                            print(f"{ERROR} No servers created by {username}.")
                            Return()

                        max_name_length = max(len(name) for _, name, _ in guilds_list)

                        for i, (guild_id, name, icon) in enumerate(guilds_list, 1):
                            current_icon_url = f"https://cdn.discordapp.com/icons/{guild_id}/{icon}.png" if icon else "No icon set"
                            print(f"{CHOICE} {start}{i:03}{end}{white} {name}")
                            guilds_dict[i] = guild_id

                        selected_input = input(f"\n{INPUT} Choice ->{white} ").strip("0")

                        try:
                            selected_num = int(selected_input)
                            selected_guild_id = guilds_dict.get(selected_num)

                            if selected_guild_id:
                                guild = next(guild for guild in guilds if guild['id'] == selected_guild_id)
                                current_icon_url = f"https://cdn.discordapp.com/icons/{guild['id']}/{guild['icon']}.png" if guild.get('icon') else "No icon set"
                                print(f"\n{INFORMATION} Current Icon URL: {white}{current_icon_url}")

                                new_icon_url = input(f"{INPUT} New Icon Path   :{white} ").strip()
                                new_icon_base64 = EncodeImageBase64(new_icon_url)

                                response = change_guild_icon(token, selected_guild_id, new_icon_url)
                                if response.status_code == 200:
                                    print(f"{SUCCESS} Server icon successfully changed.")
                                else:
                                    print(f"{ERROR} Error        : {white}{response.status_code}")
                                    print(f"{ERROR} Error Message: {white}{response.text}")
                                Return()
                            else:
                                ErrorNumber()
                        except ValueError:
                            ErrorChoice()
                    else:
                        ErrorNumber()

                elif action_input in "2":
                    guilds = get_user_guilds(token)
                    if guilds:
                        guilds = [guild for guild in guilds if guild['owner']]  

                        if not guilds:
                            print(f"{ERROR} No servers created by {username}.")
                            Return()

                        new_icon_url = input(f"{INPUT} New Icon URL:{white} ").strip()
                        new_icon_base64 = EncodeImageBase64(new_icon_url)

                        for guild in guilds:
                            guild_id = guild['id']
                            response = change_guild_icon(token, guild_id, new_icon_url)

                            if response.status_code == 200:
                                print(f"{SUCCESS} Server icon successfully changed.{white} |{green} {guild['name']} -> {new_icon_url}")
                            else:
                                print(f"{FAILED} Failed to change icon.{white}            |{red} {guild['name']} -> {new_icon_url}")

                        print(f"{INFORMATION} All servers have had their icons changed.")
                        Return()
                    else:
                        print(f"{ERROR} No servers found.")
                else:
                    ErrorChoice()
            else:
                ErrorChoice()
else:
    NoTokenFound()