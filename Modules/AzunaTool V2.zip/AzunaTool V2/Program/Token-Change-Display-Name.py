try:
    from Configuration.Utilities import *

    import requests
except:
    MissingModules()

def change_display_name(token, new_display_name):
    url = "https://discord.com/api/v10/users/@me"
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    data = {
        "global_name": new_display_name
    }

    try:
        response = requests.patch(url, headers=headers, json=data)
        return response
    except requests.RequestException as e:
        return e

with open("Token.txt", "r") as file:
    lines = file.readlines()

if lines:
    tokens = [line.strip() for line in lines if line.strip()]
    valid_tokens = []

    for token in tokens:
        info = UserInfo(token)
        if info:
            username = info.get("username", "Unknown")
            global_name = info.get("global_name", "Unknown")
            valid_tokens.append((token, username, global_name))

    if valid_tokens:
        tokens_dict = {}
        max_username_length = max(len(username) for _, username, _ in valid_tokens)
        max_displayname_length = max(len(global_name) for _, _, global_name in valid_tokens)

        for i, (token, username, global_name) in enumerate(valid_tokens, 1):
            nitro = NitroType(token)
            padded_username = username.ljust(max_username_length)
            padded_displayname = global_name.ljust(max_displayname_length)
            print(f"{CHOICE} {start}{i:02}{end} Username: {white}{padded_username} |{blue} Display Name: {white}{padded_displayname} |{blue} Nitro Type: {white}{nitro}")
            tokens_dict[i] = token

    choice_input = input(f"\n{INPUT} Choice ->{white} ").strip()

    if not choice_input.isdigit():
        ErrorChoice()
    else:
        choice = int(choice_input)
        chosen_token = tokens_dict.get(choice)

        if chosen_token:
            current_info = UserInfo(chosen_token)
            if current_info:
                current_display_name = current_info.get("global_name", "Unknown")
                print(f"\n{INFORMATION} Current Display Name:{white} {current_display_name}")
                new_display_name = input(f"{INPUT} New Display Name    :{white} ")

                response = change_display_name(chosen_token, new_display_name)

                if isinstance(response, requests.Response) and response.status_code == 200:
                    print(f"{SUCCESS} Username successfully changed.")
                    Return()
                else:
                    print(f"{ERROR} Error        : {white}{response.status_code}")
                    print(f"{ERROR} Error Message: {white}{response.json()}")
                    Return()
            else:
                NoInfoToken()
        else:
            ErrorChoice()
else:
    NoTokenFound()