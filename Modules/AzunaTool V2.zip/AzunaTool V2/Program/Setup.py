from Configuration.Utilities import *

import os, time

os.system("title AzunaTool │ Setup")

os.system("cls")
print("Installing modules required for AzunaTool:\n")
os.system("python -m pip install --upgrade pip")
os.system("python -m pip install -r requirements.txt")
print("\nRunning AzunaTool..")
time.sleep(1)
Clear()
os.system("python AzunaTool.py")